
import ast

from app.java_extractor import parse_java


class ASTAnalyzer:
    @staticmethod
    def parse_code(code: str, language: str):
        """
        Parse source code according to the specified programming language.

        Args:
            code: Source code to parse.
            language: Programming language ('python' or 'java').

        Returns:
            A tuple (syntax_tree, error_message).
            On success, error_message is None.
            On failure, syntax_tree is None.
        """
        if not isinstance(code, str):
            return None, "Invalid input: code must be a string."

        if not isinstance(language, str):
            return None, "Invalid input: language must be a string."

        normalized_language = language.strip().lower()

        if normalized_language == "python":
            return ASTAnalyzer.parse_python_ast(code)

        if normalized_language == "java":
            return ASTAnalyzer.parse_java_ast(code)

        return None, f"Unsupported language: {language}"

    @staticmethod
    def parse_python_ast(code: str):
        """Parse Python source code into an AST."""
        try:
            return ast.parse(code), None
        except SyntaxError as e:
            return None, f"SyntaxError line {e.lineno}: {e.msg}"
        except Exception as e:
            return None, f"AST Parse Error: {str(e)}"

    @staticmethod
    def parse_java_ast(code: str):
        """Parse Java source code (Java 17 syntax) with tree-sitter."""
        try:
            return parse_java(code)
        except Exception as e:
            return None, f"Java AST Parse Error: {str(e)}"
